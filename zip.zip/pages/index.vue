<template>
  <div class="container">
    <div>
      <logo />
      <h1 class="title">
        besoVue
      </h1>
      <no-ssr>
        <div v-masonry transition-duration="3s" item-selector=".item" class="masonry-container">
          <div v-masonry-tile :key="index" v-for="(item, index) in blocks" class="item">
            <img :src="item" />
          </div>
        </div>
      </no-ssr>
    </div>
  </div>
</template>

<script>
import NoSSR from 'vue-no-ssr'
import Logo from '~/components/Logo.vue'

export default {
  components: {
    Logo,
    'no-ssr': NoSSR
  },
  data () {
    return {
      blocks: [
        'http://qnimate.com/wp-content/uploads/2014/03/images2.jpg',
        'https://pbs.twimg.com/profile_images/3572978953/8c522d3ea384cd42e46a4a2498300c35_400x400.jpeg',
        'https://banbanjara.com/frontend/uploads/mega_menu/1559907931389-getaways.jpg'
      ]
    }
  },
  mounted () {
    if (typeof this.$redrawVueMasonry === 'function') {
      this.$redrawVueMasonry()
    }
  }
}
</script>

<style>
.container {
  margin: 0 auto;
  min-height: 100vh;
  width: 1200px;
  margin: 0 auto;
}

.title {
  font-family: 'Quicksand', 'Source Sans Pro', -apple-system, BlinkMacSystemFont,
    'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  display: block;
  font-weight: 300;
  font-size: 100px;
  color: #35495e;
  letter-spacing: 1px;
}

.subtitle {
  font-weight: 300;
  font-size: 42px;
  color: #526488;
  word-spacing: 5px;
  padding-bottom: 15px;
}

.links {
  padding-top: 15px;
}
</style>
